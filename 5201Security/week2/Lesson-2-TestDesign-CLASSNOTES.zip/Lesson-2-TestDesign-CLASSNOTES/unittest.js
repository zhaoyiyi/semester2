//LESSON 2 - UNIT TESTING
/**
 * Validate age is between 18 & 25 years old.
 * Returns true if age validates.
 * @param {integer} ageIn
 */
function checkAge(ageIn) {
    "use strict";
    var ageTest = false;
    if (!isNaN(ageIn)) {
        parseInt(ageIn);
    }
    if (ageIn >= 18 && ageIn <= 25) {
        ageTest = true;
    }
    return ageTest;
}

function test__checkAge(valueIn, expected) {
    "use strict";
    var result = checkAge(valueIn);
    var msgBox = document.getElementById("msgs");
    var msg = "Value: " + valueIn + " | Result: " + result + " | Expected: " + expected;
    msgBox.innerHTML += msg;
}
//LETS APPLY OUR TESTING TYPES TO THIS CODE...
test__checkAge(22, true);//TEST TO PASS
test__checkAge(300, false);//TEST TO FAIL
test__checkAge(18, true);//BOUNDARY TESTING
test__checkAge(17, false);//BOUNDARY TESTING