<footer class="footer">
  <div class="container">
    <p class="text-muted">footer.</p>
    <ul>
      <?php displayNav('li'); ?>
    </ul>
  </div>
</footer>
