<footer class="footer">
  <div class="container">
    <p class="text-muted">footer.</p>
  </div>
</footer>
