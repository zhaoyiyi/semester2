
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>php lab2</title>
  </head>
  <link rel="stylesheet" href="bootstrap.min.css" media="screen" title="no title" charset="utf-8">
  <body class="container">
    <?php include 'header.php' ?>
    <?php include 'form.php' ?>
    <?php include 'footer.php' ?>
    <script src="validate.js" charset="utf-8"></script>
  </body>
</html>
