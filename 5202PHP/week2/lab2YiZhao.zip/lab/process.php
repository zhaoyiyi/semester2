<?php


if( isset($_REQUEST['btnLogin']) ){
  // echo var_dump($_REQUEST, $_SERVER['REQUEST_METHOD']);
  echo "<h1>form information: </h1>";
  foreach ($_REQUEST as $fieldName => $value) {
    echo $fieldName . ': ' . $value . '<br />';
  }
}
